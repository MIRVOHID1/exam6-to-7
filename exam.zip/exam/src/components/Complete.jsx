// import React from 'react'

// export default function Complete() {
//   const add =()=>{

//   }
//   return (
//     <div className='container'>
//       <div className="row">
//         <div className="col-md-4 offset-3">
//           <div className="card">
//             <div className="card-header">
//               <h1 className='text-center'>Open</h1>
//             </div>
//             <div className="card-body">

//             </div>
//             <div className="card-footer">
//               <button onClick={add}>Add</button>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

import React, { useState } from "react";

export default function Complete() {
  const [count, setCount] = useState(0);

  const add = () => {
    console.log("Button clicked!");
    // Add more functionality here, for example, updating the count state
    setCount(count + 1);
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-4 offset-3">
          <div className="card">
            <div className="card-header">
              <h1 className="text-center">Open</h1>
            </div>
            <div className="card-body">
              {/* Add content to the card body if needed */}
              <p>Clicked: {count} times</p>
            </div>
            <div className="card-footer">
              <button onClick={add}>Add</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

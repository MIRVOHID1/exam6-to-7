// import React from 'react'

// export default function Inprog() {
//   const add =()=>{

//   }
//   return (
//     <div className='container'>
//       <div className="row">
//         <div className="col-md-4 offset-3">
//           <div className="card">
//             <div className="card-header">
//               <h1 className='text-center'>Open</h1>
//             </div>
//             <div className="card-body">

//             </div>
//             <div className="card-footer">
//               <button onClick={add}>Add</button>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   )
// }

import React, { useState } from "react";

export default function Inprog() {
  const [status, setStatus] = useState("In Progress");

  const add = () => {
    console.log("Button clicked!");
    // Add more functionality here, for example, updating the status state
    setStatus("Completed");
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-md-4 offset-3">
          <div className="card">
            <div className="card-header">
              <h1 className="text-center">{status}</h1>
            </div>
            <div className="card-body">
              {/* Add content to the card body if needed */}
              <p>This task is currently in progress.</p>
            </div>
            <div className="card-footer">
              <button onClick={add}>Complete</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React from "react";
import {Routes, Route} from 'react-router-dom'
import Pending from "./components/Pending";

export default function App(){

 
  return(
    <div>
      <Routes>
        <Route path="" element={<Pending/>}/>
      </Routes>
    </div>
  )
}
// import { Modal, Button } from "react-bootstrap";
// import React, { useState } from 'react';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Modal, Button } from 'bootstrap';
// export default function App() {
//   const [show, setShow] = useState(false);
//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);
//   return (
//     <>
//       <Button variant="primary" onClick={handleShow}>
//         click modal
//       </Button>
//       <Modal show={show} onHide={handleClose}>
//         <Modal.Header closeButton>
//           <Modal.Title>Modal heading</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>Hello,you're reading this text in a modal!</Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleClose}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleClose}>
//             Save Changes
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </>
//   );
// }
